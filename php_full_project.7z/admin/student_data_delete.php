<?php 
require('db_con.php');
$id = $_GET['id'];
$delete = "DELETE  FROM `student_admission_data` WHERE id = $id ";
$delete_query = mysqli_query($db_con , $delete);
if($delete_query){
    echo '
    <script>
        alert("Successfull");
    </script>
';

}else{
    echo '
    <script>
        alert("Problem");
    </script>
';
}
header('location:admin_dashboard_index.php');
?>