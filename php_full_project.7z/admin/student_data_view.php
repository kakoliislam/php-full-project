<?php 
require("db_con.php");
session_start();
if(!isset($_SESSION['User_name'])){
    header("location:../login form/login_admin_index_form.php");
}
?>

